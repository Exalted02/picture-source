<img src="{{ asset('front-assets/img/-logo1.jpg') }}" alt="{{ __('project_title') }}">
