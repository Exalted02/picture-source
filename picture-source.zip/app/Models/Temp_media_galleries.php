<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Temp_media_galleries extends Model
{
    use HasFactory;
	protected $table = 'temp_media_galleries';
}
